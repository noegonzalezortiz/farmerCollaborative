# farmerCollaborative

Noe Gonzalez

4/30/21 - Initial commit added empty html, css and js files into the repo. Files will be designated in our next meeting. 
5/4/21 - Added Basic HTML structure and links to stylesheet and script documents.
5/5/21 - Added Nav Bar with links, interactive navbar using css. Created logo and added files to the logo folder inside images.
5/10/21 - Added home and contact us pages, working contact form using formspree
5/13/21 - Fixed Htmls Home page to index.html. 
